#define CATCH_CONFIG_MAIN
#include "catch.hpp"

#include "array_list.hpp"

// force class expansion
template class ArrayList<int>;

TEST_CASE("Test", "[ArrayList]")
{
  ArrayList<int> list;
}

TEST_CASE("Lists: Test 1-indexing Corner Cases", "[Lists]")
{
  ArrayList<int> list; // same for below LinkedList<int> list;
  REQUIRE(list.isEmpty());

  REQUIRE_FALSE(list.insert(0, 0)); // invalid
  REQUIRE(list.isEmpty());          // still empty

  REQUIRE(list.insert(1, 1));     // valid
  REQUIRE(list.getLength() == 1); // length is 1

  REQUIRE_FALSE(list.remove(0));  // invalid
  REQUIRE(list.getLength() == 1); // length is still 1

  REQUIRE(list.remove(1)); // valid
  REQUIRE(list.isEmpty()); // now empty

  list.insert(1, 301);
  list.insert(2, 302);

  REQUIRE(list.getEntry(1) == 301);
  REQUIRE(list.getEntry(2) == 302);

  REQUIRE_THROWS_AS(list.getEntry(0), std::out_of_range);
  REQUIRE_THROWS_AS(list.setEntry(0, 300), std::out_of_range);

  // pos = 1 is the first item, that also indicates pos = n is the last item
  // insertion at pos=n should be valid, and insertion at pos=n+1 also being valid
  // removal at pos=1 is valid, but removal at pos=n+1 is invalid
}

TEST_CASE("Test Constructor", "[Lists]")
{
  //check if list is initialized empty with a size of 0
  ArrayList<int> list;
  REQUIRE(list.isEmpty());
  REQUIRE(list.getLength()==0);
}

TEST_CASE("Test insert and remove", "[Lists]")
{
  //create list
  ArrayList<int> list;

  // insert at valid positions
  list.insert(1, 10);
  REQUIRE(list.getLength()==1);
  REQUIRE(list.getEntry(1)==10);

  list.insert(2, 20);
  REQUIRE(list.getLength() == 2);
  REQUIRE(list.getEntry(2) == 20);

  list.insert(3,30);
  REQUIRE(list.getLength() == 3);
  REQUIRE(list.getEntry(3) == 30);

  //try insert at invalid position
  REQUIRE_FALSE(list.insert(0, 40));

  //remove items
  REQUIRE(list.remove(1));
  REQUIRE(list.getLength()==2);
  REQUIRE(list.getEntry(1)==20);
  REQUIRE(list.getEntry(2) == 30);

  REQUIRE(list.remove(1));
  REQUIRE(list.getLength() == 1);
  REQUIRE(list.getEntry(1) == 30);
}

TEST_CASE("Test clear and setEntry function", "[Lists]")
{
  ArrayList<int> list;

  //create list
  list.insert(1, 10);
  list.insert(2, 20);
  list.insert(3, 30);
  list.insert(4, 40);
  list.insert(5, 50);
  list.insert(6, 60);
  list.insert(7, 70);

  //clear list
  list.clear();

  //check if the list is empty
  REQUIRE(list.isEmpty());
  REQUIRE(list.getLength()==0);

  //test setting entry
  list.insert(1,0);
  list.setEntry(1, 10);
  REQUIRE(list.getEntry(1)==10);
}
